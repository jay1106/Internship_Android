
public class Classone {

public static void main(String[] args) {
		
	
	}
	
	
public void test(int i , String j){
	System.out.println("Testing for inheritance");
	System.out.println(i+" "+j);
}


public void test(int i , String j , int k){
	
System.out.println("Testing for inheritance");
System.out.println(i+" "+j+" "+k);
}
}
