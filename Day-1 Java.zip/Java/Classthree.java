
public class Classthree extends Classtwo  {


    public static void main(String[] args) {
		
	
//    	Classone classone = new Classone();
    	
//    	Classtwo classtwo = new Classtwo();
    	
    	
    	Classthree three = new Classthree();
    	
//    	three.test();
    	
    	
	}
	
}
